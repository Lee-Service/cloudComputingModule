<?php
include "../totalwordcount/src/totalWordCountFunction.php";
use PHPUnit\Framework\TestCase;

class TotalWordCountFunctionTest extends TestCase{
  public function testTotalWordCount()
  {
    $paragraph = "This is definitely going to work!";
    $expect = 6;
    $this->assertEquals($expect, totalWordCount($paragraph));
  }

  function testingHTTPTotalWordCountTest()
  {
    $localtesturl = 'http://localhost:8000/src/index.php/';
    //initialise curl session using local URL
    $curl = curl_init($localtesturl);
    //set options for curl session URL - return curl transfer as true
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    //ensure curl session includes header in the output
    curl_setopt($curl, CURLOPT_HEADER, 1);
    //perform the actual curl session
    $execute_url = curl_exec($curl);
    //get information about header - total size of header
    $headersize = curl_getinfo($curl, CURLINFO_HEADER_SIZE);
    $headers = substr($execute_url, 0, $headersize);
    //remove excess results from header
    $headers = explode("\r\n", $headers);
    $firstheader = $headers[0];
    //test passes if HTTP = OK
    $this->assertEquals($firstheader, "HTTP/1.1 200 OK");
    //end curl session
    curl_close($curl);
  }

}
?>