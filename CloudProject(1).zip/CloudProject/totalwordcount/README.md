# TotalWorkCount Function
A function to define how many words each paragraph contains. CI testing is conducted on the function and whether or not it can obtain the correct HTTP response code.
