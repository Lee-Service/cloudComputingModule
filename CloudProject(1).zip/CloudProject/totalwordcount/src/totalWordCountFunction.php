<?php

function totalWordCount($paragraph)
{
  $keywordcount = 0;
  //explode a paragraph into a string array
  $strarray = explode(' ', $paragraph);
  //for each word in the string array, increment a value and return it.
  foreach ($strarray as $word) {
    if (strlen($word) > 0) {
      $keywordcount++;
    }
  }
  return $keywordcount;
}
