<script>
    function keyWordCheckfunction() {
        servicelink = $keywordcheckservicelink;
        service = 2;
        paragraph = $p_content.value.toLowerCase();
        word = $k_content.value.toLowerCase();
        let xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                var j = JSON.parse(this.response);
                result = j.answer;
                console.log(result);
            }
        };
        xhttp.open("GET", serviceURL + "?paragraph=" + paragraph + "&word=" + word + "&service=" + service);
        xhttp.send();
        return;
    }

<?php
header("Access-Control-Allow-Origin: *");
header("Content-type: application:json");
// include("connection.php");
// if ($conn) {

global $p_content;
global $p_size;
global $k_content;
global $keywordcheckservicelink;
global $totalwordcountservicelink;
global $keywordnumberservicelink;

//grab list of keywords and paragraphs to test
$getcontents = file_get_contents('paragraphs.json');
$paragraphs = json_decode($getcontents, true);

//get a random paragraph and the size of the paragraph
foreach ($paragraphs as $paragraph) {
    $p_content = $paragraph[rand(0, sizeof($paragraph) - 1)];
    $p_size = str_word_count($p_content);
}

$getcontents = file_get_contents('keywords.json');
$keywords = json_decode($getcontents, true);

foreach ($keywords as $keyword) {
    $k_content = $keyword[rand(0, sizeof($keyword) - 1)];
}

$getcontents = file_get_contents('keywordcheck.json');
$keywordcheckfunction = json_decode($getcontents, true);

foreach ($keywordcheckfunction as $links) {
    for ($x = 0; $x < sizeof($links); $x++) {
        $keywordcheckservicelink = $links[$x];
        ?>
       keywordcheckfunction();
       <?php
    }
}
?>



    // function totalWordCount() {
    //     serviceURL = <?php echo $servicelink ?>;
    //     service = 1;
    //     paragraph = <?php echo $p_content ?>.value.toLowerCase();
    //     word = <?php echo $k_content ?>.value.toLowerCase();
    //     let xhttp = new XMLHttpRequest();
    //     xhttp.onreadystatechange = function() {
    //         if (this.readyState == 4 && this.status == 200) {
    //             var j = JSON.parse(this.response);
    //             result = j.answer;
    //         }
    //     };
    //     xhttp.open("GET", serviceURL + "?paragraph=" + paragraph + "&word=" + word + "&service=" + service);
    //     xhttp.send();
    //     return;
    // }

    // function keyWordAppearanceNumber() {
    //     serviceURL = <?php echo $servicelink ?>
    //     service = 3
    //     paragraph = <?php echo $p_content ?> ''.value.toLowerCase();
    //     word = <?php echo $k_content ?>.value.toLowerCase();
    //     let xhttp = new XMLHttpRequest();
    //     xhttp.onreadystatechange = function() {
    //         if (this.readyState == 4 && this.status == 200) {
    //             var j = JSON.parse(this.response);
    //             result = j.answer;
    //         }
    //     };
    //     xhttp.open("GET", serviceURL + "?paragraph=" + paragraph + "&word=" + word + "&service=" + service);
    //     xhttp.send();
    //     return;
    // }
