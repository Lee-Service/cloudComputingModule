#Folder for testing strings using the web app function.
Makes use of cron and database to test strings.
DOES NOT WORK AND NEEDS TO BE ADDRESSED IN FUTURE.