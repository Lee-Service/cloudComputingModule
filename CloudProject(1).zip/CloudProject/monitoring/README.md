# Monitoring for Webapp
This folder containers details for monitoring the service via Chron.
Details for the implementation of an email notification system (PHP Mailer) can be found at: https://www.codexworld.com/send-html-email-php-gmail-smtp-phpmailer/

