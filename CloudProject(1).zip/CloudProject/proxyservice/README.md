# Proxy Service for Webapp
This folder containers details for the proxy services which ensure that if one system goes down, another can take its place to reduce the liklihood of a single point of failure.

