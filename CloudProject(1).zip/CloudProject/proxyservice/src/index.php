<?php
global $proxyURL;
header("Access-Control-Allow-Origin: *");

/*
Send a request from frontend to proxy with a service variable to define its function
Then using the variable, send a request to the service below (1,2,3).
The result is returned to the front end via proxy url encoded as a json.
*/

// Check GET request and switch on to relevant service
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
  //array of proxy links
  $getProxyContents = file_get_contents('proxyservice.json');
  $proxyarray = json_decode($getProxyContents, true);

  //get data to make up variables
  $serviceNum = $_GET['service'];
  $paragraph = urlencode($_GET['paragraph']);
  $word = $_GET['word'];

  //ensure switches to right service, otherwise invalid
  if ($serviceNum < 1 || $serviceNum > 3) {
    echo (json_encode(array("error" => true, "message" => "Invalid service requested in proxy")));
    exit();
  } else {
    switch ($serviceNum) {

      case 1:
        foreach ($proxyarray['totalwordcount'] as $links) {
          $header_check = get_headers("$links");
          $response_code = $header_check[0];
          //set url from list of working links
          $URL = $links;
          if ($response_code == 'HTTP/1.1 200 OK') {
            break;
          }
        }
        $service = "Total wordcount";
        $response = json_decode(file_get_contents($URL . "?paragraph=" . $paragraph), true);
        $answer = $response['answer'];
        break;

      case 2:
        foreach ($proxyarray['keywordcheck'] as $links) {
          $header_check = get_headers("$links");
          $response_code = $header_check[0];
          //set url from list of working links
          $URL = $links;
          if ($response_code == 'HTTP/1.1 200 OK') {
            break;
          }
        }
        $service = "Keyword check";
        $response = json_decode(file_get_contents($URL . "?paragraph=" . $paragraph . "&word=" . $word), true);
        $answer = $response['answer'];
        break;

      case 3:
        foreach ($proxyarray['numberofkeywords'] as $links) {
          $header_check = get_headers("$links");
          $response_code = $header_check[0];
          //set url from list of working links
          $URL = $links;
          if ($response_code == 'HTTP/1.1 200 OK') {
            break;
          }
        }
        $service = "Number of times keyword appears";
        $response = json_decode(file_get_contents($URL . "?paragraph=" . $paragraph . "&word=" . $word), true);
        $answer = $response['answer'];
        break;

      default:
        break;
    }
    echo json_encode(array("error" => false, "paragraph" => $paragraph, "answer" => $answer));
    exit();
  }
} else {
  echo (json_encode(array("error" => true, "message" => "Must be GET request")));
  exit();
}

?>
</head>