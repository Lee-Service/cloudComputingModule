# App front end folder.
Front end is comprised of CSS, HTML and Javascript files.

