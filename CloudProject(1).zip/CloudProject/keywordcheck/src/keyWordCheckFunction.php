<?php
// find the first occurance in a paragraph and say whether or not the paragraph contains it
// If it does contain it, return 1 else 0.
// The paragraph variable specifies the string to search, the word variable is the string to find.

function keyWordCheck($paragraph, $word)
{
    if (strpos($paragraph, $word) !== false)
        return 1;
    else
        return 0;
}
