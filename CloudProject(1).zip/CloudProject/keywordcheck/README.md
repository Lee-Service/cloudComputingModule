# KeywordCheckFunction.
Does the function contain the key word? Y/N.

