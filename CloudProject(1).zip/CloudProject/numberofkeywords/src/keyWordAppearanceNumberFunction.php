<?php

function keyWordAppearanceNumber($paragraph, $word){
  $keywordcount=0;
//explode a paragraph into a string array
$strarray = explode(' ',$paragraph);
//for each word in the string array, if each word matches the word we're looking for,
// increment a value
foreach ($strarray as $eachword){
  if ($word == $eachword){
    $keywordcount++;
  }
}
return $keywordcount;
}
