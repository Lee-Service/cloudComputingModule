# Number of key words.
This function takes into account the frequency of a user specified key word in a paragraph from the app's front end. CI testing is conducted on the function and its ability to retrieve the correct HTTP response code.
